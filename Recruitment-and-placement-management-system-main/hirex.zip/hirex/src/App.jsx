import React, { useState, useEffect } from 'react';
import { Briefcase, Building2, Users, Upload, LogOut, Menu, X, Rocket, ArrowRight, Sparkles, CheckCircle, TrendingUp, Award, Target, Zap } from 'lucide-react';

const API_BASE = 'http://localhost:8080';

function App() {

  // For student: list of jobs they applied to
const [myApplications, setMyApplications] = useState([]);

// For company: list of students who applied to a particular job
const [jobApplicants, setJobApplicants] = useState([]);

const [selectedJobId, setSelectedJobId] = useState(null);


  const [currentPage, setCurrentPage] = useState('landing');
  const [user, setUser] = useState(null);
  const [userType, setUserType] = useState('');

  const [companyEmail, setCompanyEmail] = useState("");
  const [companyPassword, setCompanyPassword] = useState("");

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [companyName, setCompanyName] = useState('');

  const [companyJobs, setCompanyJobs] = useState([]);
  const [requiredSkills, setRequiredSkills] = useState("");

  // Job Posting
  const [role, setRole] = useState("");
  const [minCgpa, setMinCgpa] = useState("");
  const [salary, setSalary] = useState("");
  const [careerLink, setCareerLink] = useState("");

  const loadCompanyJobs = async () => {
    try {
      const res = await fetch(`${API_BASE}/job/all`);
      const data = await res.json();
      const myJobs = data.filter(j => j.company?.id === user.id);
      setCompanyJobs(myJobs);
    } catch (err) {
      console.error(err);
    }
  };

  const postJob = async () => {
    if (!role || !minCgpa || !salary || !careerLink) {
      alert("Please fill all fields");
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/job/add/${user.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          role,
          minCgpa,
          salary,
          careerLink,
          requiredSkills
        }),
      });

      if (!res.ok) throw new Error("Failed to post job");

      alert("Job posted successfully");
      setRole("");
      setMinCgpa("");
      setSalary("");
      setCareerLink("");
      setRequiredSkills("");
      setCurrentPage('companyJobs');
    } catch (err) {
      alert("Error posting job");
      console.error(err);
    }
  };


  const fetchMyApplications = async () => {
  if (!user || userType !== 'student') return;
  try {
    const res = await fetch(`${API_BASE}/applications/student/${user.id}`);
    const data = await res.json();
    setMyApplications(data);
  } catch (err) {
    console.error('Failed to fetch applications', err);
  }
};

useEffect(() => {
    fetchMyApplications();
  }, [user, userType]);


const fetchJobApplicants = async (jobId) => {
  try {
    const res = await fetch(`${API_BASE}/applications/job/${jobId}`);
    const data = await res.json();
    setJobApplicants(data);
  } catch (err) {
    console.error('Failed to fetch applicants', err);
  }
};

const updateApplicationStatus = async (applicationId, newStatus) => {
  try {
    const res = await fetch(
      `${API_BASE}/applications/status/${applicationId}?status=${newStatus}`,
      {
        method: 'PUT',
      }
    );

    if (!res.ok) throw new Error('Update failed');

    fetchJobApplicants(selectedJobId);
    fetchMyApplications();
  } catch (err) {
    console.error('Failed to update status', err);
  }
};




  const handleLogout = () => {
    setUser(null);
    setUserType(null);
    setCurrentPage('landing');
  };

  const registerCompany = async () => {
    if (!companyName.trim() || !email.trim() || !password.trim()) {
      alert("Please fill in all fields");
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/company/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          companyName,
          email,
          password
        })
      });

      if (res.ok) {
        alert("Registration successful. Please login.");
        setCurrentPage('companyLogin');
        setCompanyName("");
        setEmail("");
        setPassword("");
      } else {
        alert("Registration failed");
      }
    } catch (error) {
      console.error(error);
      alert("Server error, try again later");
    }
  };

  const handleCompanyLogin = async () => {
    if (!companyEmail.trim() || !companyPassword.trim()) {
      alert("Please enter both email and password");
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/company/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: companyEmail, password: companyPassword }),
      });

      if (!res.ok) {
        throw new Error("Invalid credentials");
      }

      const data = await res.json();
      setUser(data);
      setUserType('company');
      setCurrentPage('companyDashboard');
      setCompanyEmail("");
      setCompanyPassword("");
    } catch (err) {
      console.error(err);
      alert("Login failed. Please check your credentials or server.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
      <div className="flex-grow">
        {currentPage === 'landing' && <LandingPage setCurrentPage={setCurrentPage} setUserType={setUserType} />}
        {currentPage === 'studentLogin' && <StudentLogin setCurrentPage={setCurrentPage} setUser={setUser} setUserType={setUserType} />}

        {currentPage === 'companyLogin' && (
          <div className="max-w-md mx-auto mt-20 p-8 bg-gray-800/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-700">
            <h2 className="text-2xl font-bold mb-6 text-center text-white">Company Login</h2>

            <input
              type="email"
              placeholder="Company Email"
              value={companyEmail}
              onChange={(e) => setCompanyEmail(e.target.value)}
              className="w-full p-3 mb-4 bg-gray-700/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-[#df73ff] focus:ring-2 focus:ring-[#df73ff]/20 outline-none transition-all"
            />

            <input
              type="password"
              placeholder="Password"
              value={companyPassword}
              onChange={(e) => setCompanyPassword(e.target.value)}
              className="w-full p-3 mb-4 bg-gray-700/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-[#df73ff] focus:ring-2 focus:ring-[#df73ff]/20 outline-none transition-all"
            />

            <button
              onClick={handleCompanyLogin}
              className="w-full p-3 bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white font-bold rounded-xl hover:shadow-lg hover:shadow-[#df73ff]/30 transition-all"
            >
              Login
            </button>

            <button
              onClick={() => setCurrentPage('companyRegister')}
              className="w-full mt-4 p-3 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:shadow-lg transition-all"
            >
              Register New Company
            </button>

            <button
              onClick={() => setCurrentPage('landing')}
              className="w-full mt-4 p-3 bg-gray-700 text-gray-300 rounded-xl hover:bg-gray-600 transition-all"
            >
              Back
            </button>
          </div>
        )}

        {currentPage === 'studentRegister' && <StudentRegister setCurrentPage={setCurrentPage} />}
        {currentPage === 'studentDashboard' && user && (
  <StudentDashboard 
    user={user} 
    handleLogout={handleLogout} 
    myApplications={myApplications} 
    fetchMyApplications={fetchMyApplications} 
  />
)}

  {currentPage === 'companyJobApplicants' && selectedJobId && (
  <div className="max-w-4xl mx-auto mt-20 p-8 bg-gray-800/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-700">
    <h2 className="text-3xl font-bold text-white mb-6 text-center">
      Applicants for Job
    </h2>

    {jobApplicants.length === 0 ? (
      <p className="text-gray-400 text-center">No students have applied yet.</p>
    ) : (
      jobApplicants.map(app => (
        <div key={app.id} className="bg-gray-700/50 rounded-xl p-5 mb-4 border border-gray-600">
          <h3 className="text-xl font-bold text-white">{app.student.name}</h3>
          <p className="text-gray-300">Email: {app.student.email}</p>
          <p className="text-gray-300">Branch: {app.student.branch}</p>
          <p className="text-gray-300">CGPA: {app.student.cgpa}</p>
          <p className="text-gray-300">Skills: {app.student.skills}</p>
          <p className="text-[#df73ff] font-bold">Status: {app.status}</p>
           {/* ACTION BUTTONS */}
    {app.status === 'Applied' && (
      <div className="flex gap-4 mt-4">
        <button
          onClick={() => updateApplicationStatus(app.id, 'ACCEPTED')}
          className="flex-1 py-2 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-500 transition"
        >
          Accept
        </button>

        <button
          onClick={() => updateApplicationStatus(app.id, 'REJECTED')}
          className="flex-1 py-2 bg-red-600 text-white font-bold rounded-xl hover:bg-red-500 transition"
        >
          Reject
        </button>
      </div>
    )}
        </div>
      ))
    )}

    <button
      onClick={() => setCurrentPage('companyJobs')}
      className="w-full mt-6 p-3 bg-gray-700 text-gray-300 rounded-xl hover:bg-gray-600 transition-all"
    >
      Back to Jobs
    </button>
  </div>
)}


        
        {currentPage === 'companyDashboard' && userType === 'company' && user && (
          <div className="max-w-4xl mx-auto mt-20 p-8 bg-gray-800/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-700">
            <h2 className="text-3xl font-bold mb-4 text-center text-white">
              Welcome, {user.companyName}
            </h2>

            <p className="text-center mb-6 text-gray-400">
              This is your company dashboard
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <button
                onClick={() => setCurrentPage('companyPostJob')}
                className="p-4 bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white rounded-xl font-bold hover:shadow-lg hover:shadow-[#df73ff]/30 transition-all"
              >
                Post New Job
              </button>

              <button
                onClick={() => {
                  loadCompanyJobs();
                  setCurrentPage('companyJobs');
                }}
                className="p-4 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:shadow-lg transition-all"
              >
                View Posted Jobs
              </button>
            </div>

            <button
              onClick={handleLogout}
              className="w-full mt-6 p-3 bg-gray-700 text-gray-300 rounded-xl hover:bg-gray-600 transition-all"
            >
              Logout
            </button>
          </div>
        )}

        {currentPage === 'companyRegister' && (
          <div className="max-w-md mx-auto mt-20 p-8 bg-gray-800/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-700">
            <h2 className="text-2xl font-bold mb-6 text-center text-white">Company Registration</h2>

            <input
              type="text"
              placeholder="Company Name"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              className="w-full p-3 mb-4 bg-gray-700/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-[#df73ff] focus:ring-2 focus:ring-[#df73ff]/20 outline-none transition-all"
            />
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3 mb-4 bg-gray-700/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-[#df73ff] focus:ring-2 focus:ring-[#df73ff]/20 outline-none transition-all"
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 mb-4 bg-gray-700/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-[#df73ff] focus:ring-2 focus:ring-[#df73ff]/20 outline-none transition-all"
            />

            <button
              onClick={registerCompany}
              className="w-full p-3 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white font-bold rounded-xl hover:shadow-lg transition-all"
            >
              Register
            </button>

            <button
              onClick={() => setCurrentPage('companyLogin')}
              className="w-full mt-4 p-3 bg-gray-700 text-gray-300 rounded-xl hover:bg-gray-600 transition-all"
            >
              Back to Login
            </button>
          </div>
        )}

        {currentPage === 'companyPostJob' && userType === 'company' && (
          <div className="max-w-xl mx-auto mt-20 p-8 bg-gray-800/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-700">
            <h2 className="text-2xl font-bold mb-6 text-center text-white">Post New Job</h2>

            <input
              type="text"
              placeholder="Job Role"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="w-full p-3 mb-4 bg-gray-700/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-[#df73ff] focus:ring-2 focus:ring-[#df73ff]/20 outline-none transition-all"
            />

            <input
              type="number"
              placeholder="Minimum CGPA"
              value={minCgpa}
              onChange={(e) => setMinCgpa(e.target.value)}
              className="w-full p-3 mb-4 bg-gray-700/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-[#df73ff] focus:ring-2 focus:ring-[#df73ff]/20 outline-none transition-all"
            />

            <input
              type="number"
              placeholder="Salary"
              value={salary}
              onChange={(e) => setSalary(e.target.value)}
              className="w-full p-3 mb-4 bg-gray-700/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-[#df73ff] focus:ring-2 focus:ring-[#df73ff]/20 outline-none transition-all"
            />

            <input
              type="text"
              placeholder="Required Skills (e.g. Java, Spring Boot, React)"
              value={requiredSkills}
              onChange={(e) => setRequiredSkills(e.target.value)}
              className="w-full p-3 mb-4 bg-gray-700/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-[#df73ff] focus:ring-2 focus:ring-[#df73ff]/20 outline-none transition-all"
            />

            <input
              type="url"
              placeholder="Career Page Link"
              value={careerLink}
              onChange={(e) => setCareerLink(e.target.value)}
              className="w-full p-3 mb-4 bg-gray-700/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-[#df73ff] focus:ring-2 focus:ring-[#df73ff]/20 outline-none transition-all"
            />

            <button
              onClick={postJob}
              className="w-full p-3 bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white font-bold rounded-xl hover:shadow-lg hover:shadow-[#df73ff]/30 transition-all"
            >
              Submit Job
            </button>

            <button
              onClick={() => setCurrentPage('companyDashboard')}
              className="w-full mt-4 p-3 bg-gray-700 text-gray-300 rounded-xl hover:bg-gray-600 transition-all"
            >
              Back
            </button>
          </div>
        )}

        {currentPage === 'companyJobs' && user && (
          <div className="max-w-4xl mx-auto mt-20 p-8 bg-gray-800/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-700">
            <h2 className="text-2xl font-bold mb-6 text-center text-white">
              Your Posted Jobs
            </h2>

            {companyJobs.length === 0 ? (
              <p className="text-center text-gray-400">
                No jobs posted yet
              </p>
            ) : (
              companyJobs.map(job => (
                <div
                  key={job.id}
                  className="bg-gray-700/50 border border-gray-600 rounded-xl p-5 mb-4"
                >
                  <h3 className="text-xl font-bold text-white">{job.role}</h3>
                  <p className="text-gray-300">Min CGPA: {job.minCgpa}</p>
                  <p className="mt-2 text-gray-300">
                    <strong className="text-[#df73ff]">Required Skills:</strong> {job.requiredSkills}
                  </p>
                  <p className="text-gray-300">Salary: ₹{job.salary}</p>
                  <a
                    href={job.careerLink}
                    target="_blank"
                    className="text-[#df73ff] underline hover:text-[#eb9dff] transition-colors"
                  >
                    Career Page
                  </a>

                  <button
  onClick={async () => {
    setSelectedJobId(job.id);
    await fetchJobApplicants(job.id);
    setCurrentPage('companyJobApplicants');
  }}
  className="mt-4 w-full py-2 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white font-bold rounded-xl hover:shadow-lg transition-all"
>
  View Applicants
</button>



                </div>
              ))
            )}

            <button
              onClick={() => setCurrentPage('companyDashboard')}
              className="w-full mt-6 p-3 bg-gray-700 text-gray-300 rounded-xl hover:bg-gray-600 transition-all"
            >
              Back
            </button>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );


function LandingPage({ setCurrentPage, setUserType }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen relative overflow-hidden bg-gray-950">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-96 h-96 -top-20 -left-20 bg-gradient-to-br from-[#df73ff] to-[#9b30ff] rounded-full blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute w-96 h-96 top-40 right-0 bg-gradient-to-br from-[#df73ff] to-[#ff73b9] rounded-full blur-3xl opacity-15 animate-pulse delay-1000"></div>
        <div className="absolute w-96 h-96 bottom-0 left-1/3 bg-gradient-to-br from-[#b44fff] to-[#df73ff] rounded-full blur-3xl opacity-15 animate-pulse delay-2000"></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-50 bg-gray-900/70 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-3 group">
              <div className="w-12 h-12 bg-gradient-to-br from-[#df73ff] to-[#b44fff] rounded-xl flex items-center justify-center transform group-hover:rotate-12 transition-all shadow-lg shadow-[#df73ff]/30">
                <Briefcase className="w-6 h-6 text-white" />
              </div>
              <span className="text-3xl font-black bg-gradient-to-r from-[#df73ff] via-[#eb9dff] to-[#ff73d4] bg-clip-text text-transparent">
                HireX
              </span>
            </div>
            
            <div className="hidden md:flex items-center space-x-4">
              <button
                onClick={() => {
                  setUserType('student');
                  setCurrentPage('studentLogin');
                }}
                className="px-6 py-3 bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white rounded-xl font-bold hover:shadow-xl hover:shadow-[#df73ff]/30 transform hover:scale-105 transition-all"
              >
                Student Portal
              </button>
              <button
                onClick={() => {
                  setUserType('company');
                  setCurrentPage('companyLogin');
                }}
                className="px-6 py-3 bg-gray-800 text-[#df73ff] border-2 border-[#df73ff]/50 rounded-xl font-bold hover:bg-gray-700 hover:shadow-xl hover:shadow-[#df73ff]/20 transform hover:scale-105 transition-all"
              >
                Company Portal
              </button>
            </div>
            

            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden p-2 rounded-xl hover:bg-gray-800 text-white">
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {mobileMenuOpen && (
            <div className="md:hidden pb-4 space-y-2">
              <button
                onClick={() => { setUserType('student'); setCurrentPage('studentLogin'); setMobileMenuOpen(false); }}
                className="w-full px-4 py-3 bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white rounded-xl font-bold"
              >
                Student Portal
              </button>
              <button
                onClick={() => { setUserType('company'); setCurrentPage('companyLogin'); setMobileMenuOpen(false); }}
                className="w-full px-4 py-3 bg-gray-800 text-[#df73ff] border-2 border-[#df73ff]/50 rounded-xl font-bold"
              >
                Company Portal
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 pt-20 pb-32">
        <div className="text-center">
          {/* <div className="inline-flex items-center px-5 py-2 bg-gray-800/80 rounded-full mb-8 border-2 border-[#df73ff]/30">
            <Sparkles className="w-5 h-5 text-[#df73ff] mr-2" />
            <span className="text-sm font-bold text-[#df73ff]">AI-Powered Recruitment Platform</span>
          </div> */}
          
          <h1 className="text-6xl lg:text-7xl font-black mb-8 leading-tight">
            <span className="text-white">Land Your</span>
            <br />
            <span className="bg-gradient-to-r from-[#df73ff] via-[#eb9dff] to-[#ff73d4] bg-clip-text text-transparent">
              Dream Career
            </span>
          </h1>

          <p className="text-xl lg:text-2xl text-gray-400 mb-12 max-w-3xl mx-auto font-medium">
            Connect with top companies, discover perfect opportunities, and accelerate your career with intelligent matching technology
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <button
              onClick={() => { setUserType('student'); setCurrentPage('studentRegister'); }}
              className="group px-10 py-5 bg-gradient-to-r from-[#df73ff] via-[#c754ff] to-[#b44fff] text-white rounded-2xl text-lg font-bold shadow-2xl shadow-[#df73ff]/30 hover:shadow-[#df73ff]/50 transform hover:scale-105 transition-all flex items-center justify-center"
            >
              Get Started Free
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-2 transition-transform" />
            </button>
            <button
              onClick={() => { setUserType('company'); setCurrentPage('companyLogin'); }}
              className="px-10 py-5 bg-gray-800 text-[#df73ff] border-2 border-[#df73ff]/50 rounded-2xl text-lg font-bold hover:bg-gray-700 transition-all shadow-xl transform hover:scale-105"
            >
              Hire Top Talent
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-3xl mx-auto">
            {[
              { number: '12K+', label: 'Active Students' },
              { number: '800+', label: 'Partner Companies' },
              { number: '98%', label: 'Success Rate' }
            ].map((stat, i) => (
              <div key={i} className="bg-gray-800/60 backdrop-blur-sm rounded-2xl p-6 border border-gray-700 hover:border-[#df73ff]/50 transition-all">
                <div className="text-5xl font-black bg-gradient-to-r from-[#df73ff] to-[#ff73d4] bg-clip-text text-transparent">{stat.number}</div>
                <div className="text-gray-400 font-bold mt-2">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Features */}
        <div className="mt-32 grid md:grid-cols-3 gap-8">
          {[
            { 
              icon: <Users className="w-8 h-8 text-white" />, 
              title: 'For Students', 
              desc: 'Browse opportunities, track applications, and get AI-powered job recommendations tailored to your profile'
            },
            { 
              icon: <Building2 className="w-8 h-8 text-white" />, 
              title: 'For Companies', 
              desc: 'Post jobs instantly, access pre-screened candidates, and hire the perfect match with smart filtering'
            },
            { 
              icon: <Rocket className="w-8 h-8 text-white" />, 
              title: 'Smart Matching', 
              desc: 'Advanced AI algorithms match candidates with opportunities based on skills, CGPA, and preferences'
            }
          ].map((feature, i) => (
            <div key={i} className="group bg-gray-800/70 backdrop-blur-sm rounded-3xl p-8 border-2 border-gray-700 hover:border-[#df73ff]/50 transition-all hover:shadow-2xl hover:shadow-[#df73ff]/10 transform hover:-translate-y-2">
              <div className="w-16 h-16 bg-gradient-to-br from-[#df73ff] to-[#b44fff] rounded-2xl flex items-center justify-center mb-6 transform group-hover:scale-110 group-hover:rotate-6 transition-all shadow-lg shadow-[#df73ff]/30">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-black mb-4 text-white">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-32 bg-gradient-to-r from-[#df73ff] via-[#c754ff] to-[#b44fff] rounded-3xl p-16 text-center shadow-2xl shadow-[#df73ff]/30">
          <h2 className="text-5xl font-black text-white mb-6">Ready to Get Started?</h2>
          <p className="text-2xl text-white/80 mb-10 font-medium">Join thousands already transforming their careers</p>
          <button
            onClick={() => { setUserType('student'); setCurrentPage('studentRegister'); }}
            className="px-12 py-6 bg-gray-900 text-[#df73ff] rounded-2xl text-xl font-black hover:bg-gray-800 transition-all shadow-2xl transform hover:scale-110"
          >
            Create Free Account
          </button>
        </div>
      </div>
    </div>
  );
}
}

function StudentLogin({ setCurrentPage, setUser, setUserType }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch(`${API_BASE}/students/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });

      if (!response.ok) {
        throw new Error('Invalid credentials');
      }

      const data = await response.json();
      setUser(data);
      setUserType('student');
      setCurrentPage('studentDashboard');
    } catch (err) {
      console.error(err);
      setError('Login failed or server not running');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden bg-gray-950">
      <div className="absolute top-20 left-10 w-96 h-96 bg-[#df73ff] rounded-full blur-3xl opacity-15"></div>
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#b44fff] rounded-full blur-3xl opacity-15"></div>
      
      <div className="max-w-md w-full bg-gray-800/80 backdrop-blur-xl rounded-3xl shadow-2xl p-10 relative z-10 border border-gray-700">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-[#df73ff] to-[#b44fff] rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl shadow-[#df73ff]/30">
            <Briefcase className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-4xl font-black text-white">Welcome Back!</h2>
          <p className="text-gray-400 mt-2 text-lg font-medium">Login to your account</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-900/50 border-2 border-red-500 text-red-300 rounded-xl font-bold">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-black text-gray-300 mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-5 py-4 bg-gray-700/50 border-2 border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-4 focus:ring-[#df73ff]/20 focus:border-[#df73ff] transition-all outline-none"
              placeholder="your.email@example.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-black text-gray-300 mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-5 py-4 bg-gray-700/50 border-2 border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-4 focus:ring-[#df73ff]/20 focus:border-[#df73ff] transition-all outline-none"
              placeholder="••••••••"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white rounded-xl text-lg font-black hover:shadow-2xl hover:shadow-[#df73ff]/30 transform hover:scale-105 transition-all disabled:opacity-50"
          >
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>

        <div className="mt-8 text-center space-y-3">
          <p className="text-gray-400">
            No account?{' '}
            <button onClick={() => setCurrentPage('studentRegister')} className="text-[#df73ff] font-bold hover:underline">
              Register here
            </button>
          </p>
          <button onClick={() => setCurrentPage('landing')} className="text-gray-500 hover:text-gray-300 font-bold">
            ← Back
          </button>
        </div>
      </div>
    </div>
  );
}

function StudentRegister({ setCurrentPage }) {
  const [formData, setFormData] = useState({ name: '', email: '', password: '', branch: '', cgpa: '', skills: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch(`${API_BASE}/students/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          branch: formData.branch,
          cgpa: Number(formData.cgpa),
          skills: formData.skills
        }),
      });

      if (!response.ok) {
        throw new Error('Registration failed');
      }

      const message = await response.text();
      console.log(message);

      setSuccess(true);
      setTimeout(() => setCurrentPage('studentLogin'), 1500);
    } catch (err) {
      console.error(err);
      setError('Cannot connect to server (8080)');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 relative overflow-hidden bg-gray-950">
      <div className="absolute top-10 left-20 w-96 h-96 bg-[#df73ff] rounded-full blur-3xl opacity-15"></div>
      <div className="absolute bottom-10 right-20 w-96 h-96 bg-[#b44fff] rounded-full blur-3xl opacity-15"></div>
      
      <div className="max-w-3xl w-full bg-gray-800/80 backdrop-blur-xl rounded-3xl shadow-2xl p-10 relative z-10 border border-gray-700">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-[#df73ff] to-[#b44fff] rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl shadow-[#df73ff]/30">
            <Users className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-4xl font-black text-white">Create Account</h2>
          <p className="text-gray-400 mt-2 text-lg font-medium">Join thousands of students</p>
        </div>

        {error && <div className="mb-6 p-4 bg-red-900/50 border-2 border-red-500 text-red-300 rounded-xl font-bold">{error}</div>}
        {success && (
          <div className="mb-6 p-4 bg-emerald-900/50 border-2 border-emerald-500 text-emerald-300 rounded-xl font-bold flex items-center">
            <CheckCircle className="w-5 h-5 mr-2" />
            Success! Redirecting...
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-black text-gray-300 mb-2">Full Name</label>
              <input type="text" name="name" value={formData.name} onChange={handleChange} className="w-full px-5 py-4 bg-gray-700/50 border-2 border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-4 focus:ring-[#df73ff]/20 focus:border-[#df73ff] transition-all outline-none" placeholder="John Doe" required />
            </div>

            <div>
              <label className="block text-sm font-black text-gray-300 mb-2">Email</label>
              <input type="email" name="email" value={formData.email} onChange={handleChange} className="w-full px-5 py-4 bg-gray-700/50 border-2 border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-4 focus:ring-[#df73ff]/20 focus:border-[#df73ff] transition-all outline-none" placeholder="john@example.com" required />
            </div>

            <div>
              <label className="block text-sm font-black text-gray-300 mb-2">Password</label>
              <input type="password" name="password" value={formData.password} onChange={handleChange} className="w-full px-5 py-4 bg-gray-700/50 border-2 border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-4 focus:ring-[#df73ff]/20 focus:border-[#df73ff] transition-all outline-none" placeholder="••••••••" required />
            </div>

            <div>
              <label className="block text-sm font-black text-gray-300 mb-2">Branch</label>
              <select name="branch" value={formData.branch} onChange={handleChange} className="w-full px-5 py-4 bg-gray-700/50 border-2 border-gray-600 rounded-xl text-white focus:ring-4 focus:ring-[#df73ff]/20 focus:border-[#df73ff] transition-all outline-none" required>
                <option value="" className="bg-gray-800">Select</option>
                <option value="CSE" className="bg-gray-800">Computer Science</option>
                <option value="ECE" className="bg-gray-800">Electronics</option>
                <option value="EEE" className="bg-gray-800">Electrical</option>
                <option value="MECH" className="bg-gray-800">Mechanical</option>
                <option value="CIVIL" className="bg-gray-800">Civil</option>
                <option value="IT" className="bg-gray-800">IT</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-black text-gray-300 mb-2">CGPA</label>
              <input type="number" step="0.01" name="cgpa" value={formData.cgpa} onChange={handleChange} className="w-full px-5 py-4 bg-gray-700/50 border-2 border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-4 focus:ring-[#df73ff]/20 focus:border-[#df73ff] transition-all outline-none" placeholder="8.5" min="0" max="10" required />
            </div>

            <div>
              <label className="block text-sm font-black text-gray-300 mb-2">Skills</label>
              <input type="text" name="skills" value={formData.skills} onChange={handleChange} className="w-full px-5 py-4 bg-gray-700/50 border-2 border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-4 focus:ring-[#df73ff]/20 focus:border-[#df73ff] transition-all outline-none" placeholder="Java, React, Python" required />
            </div>
          </div>

          <button type="submit" disabled={loading} className="w-full py-4 bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white rounded-xl text-lg font-black hover:shadow-2xl hover:shadow-[#df73ff]/30 transform hover:scale-105 transition-all disabled:opacity-50">
            {loading ? 'Creating Account...' : 'Create Account'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-gray-400">
            Have an account?{' '}
            <button onClick={() => setCurrentPage('studentLogin')} className="text-[#df73ff] font-bold hover:underline">
              Login
            </button>
          </p>
          <button onClick={() => setCurrentPage('landing')} className="text-gray-500 hover:text-gray-300 font-bold mt-2">
            ← Back
          </button>
        </div>
      </div>
    </div>
  );
}

function StudentDashboard({ user, handleLogout, myApplications, fetchMyApplications }) {
  const [activeTab, setActiveTab] = useState('jobs');
  const [jobs, setJobs] = useState([]);
  const [resume, setResume] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    name: user.name,
    branch: user.branch,
    cgpa: user.cgpa,
    skills: user.skills
  });

  const handleProfileChange = (e) => {
    setProfileData({
      ...profileData,
      [e.target.name]: e.target.value
    });
  };

  const handleUpdateProfile = async () => {
    try {
      const response = await fetch(`${API_BASE}/students/update/${user.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: profileData.name,
          branch: profileData.branch,
          cgpa: Number(profileData.cgpa),
          skills: profileData.skills
        })
      });

      if (!response.ok) throw new Error("Update failed");

      const updatedUser = await response.json();
      Object.assign(user, updatedUser);
      setIsEditing(false);
      setMessage("Profile updated successfully!");
      setTimeout(() => setMessage(''), 3000);
    } catch (err) {
      console.error(err);
      setMessage("Profile update failed");
    }
  };

  useEffect(() => {
    fetchJobs();
    fetchResume();
    fetchMyApplications();
  }, []);

  const fetchJobs = async () => {
    try {
      const response = await fetch(`${API_BASE}/job/all`);
      if (response.ok) {
        const data = await response.json();
        setJobs(data);
      }
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const fetchResume = async () => {
    try {
      const response = await fetch(`${API_BASE}/resumes/student/${user.id}`);
      if (response.ok) {
        const data = await response.json();
        setResume(data);
      }
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const handleFileUpload = async () => {
    if (!selectedFile) {
      setMessage('Please select a file');
      return;
    }

    setLoading(true);
    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      const response = await fetch(`${API_BASE}/resumes/upload/${user.id}`, {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        setMessage('Resume uploaded!');
        fetchResume();
        setSelectedFile(null);
      } else {
        setMessage('Upload failed');
      }
    } catch (err) {
      setMessage('Connection error');
    } finally {
      setLoading(false);
    }
  };

  const handleApplyJob = async (jobId) => {
    try {
      const response = await fetch(`${API_BASE}/applications/apply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          student: { id: user.id },
          job: { id: jobId },
          status: 'Applied'
        }),
      });

      if (response.ok) {
        setMessage('Application submitted!');
        setTimeout(() => setMessage(''), 3000);
      }
    } catch (err) {
      setMessage('Application failed');
    }
  };

  const eligibleJobs = jobs.filter(job => user.cgpa >= job.minCgpa);

  return (
    <div className="min-h-screen bg-gray-950">
      <header className="bg-gray-900/70 backdrop-blur-md border-b border-gray-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#df73ff] to-[#b44fff] rounded-xl flex items-center justify-center shadow-lg shadow-[#df73ff]/30">
                <Briefcase className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-black bg-gradient-to-r from-[#df73ff] to-[#ff73d4] bg-clip-text text-transparent">HireX</h1>
                <p className="text-sm text-gray-400 font-bold">Welcome, {user.name}</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center space-x-2 px-5 py-3 bg-gradient-to-r from-red-600 to-pink-600 text-white rounded-xl hover:shadow-xl transition-all transform hover:scale-105 font-bold"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-8">
        <div className="bg-gray-800/70 backdrop-blur-sm rounded-2xl shadow-lg p-2 flex space-x-2 border border-gray-700">
          {['jobs', 'profile', 'resume', 'applications'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-4 rounded-xl font-black transition-all ${
                activeTab === tab
                  ? 'bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white shadow-lg shadow-[#df73ff]/30'
                  : 'text-gray-400 hover:bg-gray-700'
              }`}
            >
              {tab === 'jobs' ? 'Browse Jobs' :
              tab === 'profile' ? 'My Profile' :
              tab === 'resume' ? 'Resume' :
              'My Applications'}
            </button>
          ))}
        </div>

        {message && (
          <div className="mt-6 p-5 bg-emerald-900/50 border-2 border-emerald-500 text-emerald-300 rounded-2xl font-bold shadow-lg">
            {message}
          </div>
        )}

        <div className="mt-8">
          {activeTab === 'jobs' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-4xl font-black text-white">Available Jobs</h2>
                <span className="px-5 py-2 bg-gray-800 text-[#df73ff] rounded-full font-black border-2 border-[#df73ff]/30">
                  {eligibleJobs.length} Jobs
                </span>
              </div>
              
              {eligibleJobs.length === 0 ? (
                <div className="bg-gray-800/70 backdrop-blur-sm rounded-3xl shadow-lg p-12 text-center border border-gray-700">
                  <Briefcase className="w-20 h-20 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400 text-lg font-bold">No jobs available matching your profile</p>
                </div>
              ) : (
                eligibleJobs.map((job) => (
                  <div key={job.id} className="bg-gray-800/70 backdrop-blur-sm rounded-2xl shadow-lg p-8 hover:shadow-2xl transition-all border border-gray-700 hover:border-[#df73ff]/50">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="text-2xl font-black text-white">{job.role}</h3>
                        <p className="text-gray-400 mt-2 font-bold text-lg">
                          {job.company?.companyName || 'Company'} • {job.company?.location || 'Location'}
                        </p>
                        <div className="flex items-center space-x-4 mt-4">
                          <span className="px-4 py-2 bg-[#df73ff]/20 text-[#df73ff] rounded-lg font-black border border-[#df73ff]/30">
                            Min CGPA: {job.minCgpa}
                          </span>
                          <span className="px-4 py-2 bg-emerald-900/50 text-emerald-400 rounded-lg font-black border border-emerald-500/30">
                            ₹{job.salary.toLocaleString()} LPA
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleApplyJob(job.id)}
                        className="px-8 py-4 bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white rounded-xl hover:shadow-xl hover:shadow-[#df73ff]/30 transition-all font-black transform hover:scale-105"
                      >
                        Apply Now
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'profile' && (
            <div className="bg-gray-800/70 backdrop-blur-sm rounded-3xl shadow-lg p-10 border border-gray-700">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-4xl font-black text-white">My Profile</h2>

                {!isEditing ? (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white font-bold hover:shadow-lg hover:shadow-[#df73ff]/30 transition"
                  >
                    Edit Profile
                  </button>
                ) : (
                  <div className="flex gap-4">
                    <button
                      onClick={handleUpdateProfile}
                      className="px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 text-white font-bold hover:shadow-lg transition"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setIsEditing(false)}
                      className="px-6 py-3 rounded-xl bg-gray-600 text-white font-bold hover:bg-gray-500 transition"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                {[
                  { label: 'Name', name: 'name', value: profileData.name },
                  { label: 'Branch', name: 'branch', value: profileData.branch },
                  { label: 'CGPA', name: 'cgpa', value: profileData.cgpa }
                ].map((item, i) => (
                  <div
                    key={i}
                    className="p-6 bg-gray-700/50 rounded-2xl border-2 border-gray-600"
                  >
                    <label className="block text-sm font-black text-gray-400 mb-2">
                      {item.label}
                    </label>

                    {!isEditing ? (
                      <p className="text-2xl font-black text-white">
                        {item.value}
                      </p>
                    ) : (
                      <input
                        type="text"
                        name={item.name}
                        value={item.value}
                        onChange={handleProfileChange}
                        className="w-full px-4 py-3 rounded-xl bg-gray-800 border-2 border-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-[#df73ff]/50 focus:border-[#df73ff]"
                      />
                    )}
                  </div>
                ))}

                <div className="md:col-span-2 p-6 bg-gray-700/50 rounded-2xl border-2 border-gray-600">
                  <label className="block text-sm font-black text-gray-400 mb-2">
                    Skills
                  </label>

                  {!isEditing ? (
                    <p className="text-2xl font-black text-white">
                      {profileData.skills}
                    </p>
                  ) : (
                    <textarea
                      name="skills"
                      value={profileData.skills}
                      onChange={handleProfileChange}
                      rows={3}
                      className="w-full px-4 py-3 rounded-xl bg-gray-800 border-2 border-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-[#df73ff]/50 focus:border-[#df73ff]"
                    />
                  )}
                </div>

                <div className="md:col-span-2 p-6 bg-gray-900/50 rounded-2xl border-2 border-gray-700">
                  <label className="block text-sm font-black text-gray-500 mb-2">
                    Email (cannot be changed)
                  </label>
                  <p className="text-2xl font-black text-gray-400">
                    {user.email}
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'applications' && (
  <div className="mt-8 space-y-4">
    <h2 className="text-3xl font-black text-white mb-4">My Applications</h2>

    {myApplications.length === 0 ? (
      <p className="text-gray-400">You haven’t applied to any jobs yet.</p>
    ) : (
      myApplications.map(app => (
        <div key={app.id} className="bg-gray-800/70 p-5 rounded-2xl border border-gray-700">
          <h3 className="text-xl font-bold text-white">{app.job.role}</h3>
          <p className="text-gray-300">Company: {app.job.company?.companyName}</p>
          <p className="text-gray-300">Status: <span className="text-[#df73ff]">{app.status}</span></p>
        </div>
      ))
    )}
  </div>
)}


          {activeTab === 'resume' && (
            <div className="bg-gray-800/70 backdrop-blur-sm rounded-3xl shadow-lg p-10 border border-gray-700">
              <h2 className="text-4xl font-black text-white mb-8">Resume Management</h2>
              
              {resume ? (
                <div className="mb-8 p-6 bg-emerald-900/30 border-2 border-emerald-500/50 rounded-2xl">
                  <p className="text-emerald-400 font-black text-lg mb-2 flex items-center">
                    <CheckCircle className="w-6 h-6 mr-2" />
                    Resume Uploaded
                  </p>
                  <p className="text-gray-300 font-bold">File: {resume.fileName}</p>
                  <p className="text-gray-400 text-sm font-bold">Type: {resume.fileType}</p>
                </div>
              ) : (
                <p className="text-gray-400 mb-6 text-lg font-bold">No resume uploaded yet</p>
              )}

              <div>
                <label className="block text-lg font-black text-gray-300 mb-4">
                  Upload Resume (PDF, DOC, DOCX)
                </label>
                <input
                  type="file"
                  onChange={(e) => setSelectedFile(e.target.files[0])}
                  accept=".pdf,.doc,.docx"
                  className="w-full px-5 py-4 bg-gray-700/50 border-2 border-gray-600 rounded-xl text-gray-300 focus:ring-4 focus:ring-[#df73ff]/20 mb-6 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-[#df73ff] file:text-white file:font-bold"
                />
                <button
                  onClick={handleFileUpload}
                  disabled={loading || !selectedFile}
                  className="px-8 py-4 bg-gradient-to-r from-[#df73ff] to-[#b44fff] text-white rounded-xl font-black hover:shadow-xl hover:shadow-[#df73ff]/30 transition-all transform hover:scale-105 disabled:opacity-50 flex items-center space-x-2"
                >
                  <Upload className="w-5 h-5" />
                  <span>{loading ? 'Uploading...' : 'Upload Resume'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="mt-20 bg-gray-900/70 backdrop-blur-md border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-10">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-gray-400 font-bold text-center md:text-left">
            © {new Date().getFullYear()} <span className="text-[#df73ff]">HireX</span>. All rights reserved.
          </p>

          <div className="flex space-x-6">
            <a
              href="https://www.linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-[#df73ff] transition-all font-bold"
            >
              LinkedIn
            </a>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-[#df73ff] transition-all font-bold"
            >
              GitHub
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-[#df73ff] transition-all font-bold"
            >
              Twitter
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default App;
